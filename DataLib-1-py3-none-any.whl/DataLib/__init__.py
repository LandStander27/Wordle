import os
import pickle

class exceptions():
      class InvalidFile(FileNotFoundError):
            "Invalid file path"

      class KeyDoesNotExist(Exception):
            "Key in a data file doesn't exist"

class File():
      def __init__(self, filename) -> None:
            if (os.path.exists(filename)):
                  self.FilePath = os.path.abspath(filename)
                  self.DataToSave = {

                  }

            else:
                  
                 raise exceptions.InvalidFile()

      def SaveKey(self, key: str, data: str) -> None:
            self.DataToSave[key] = data

      def ReadKey(self, key: str) -> str:
            if (os.path.getsize(self.FilePath)) < 1:
                  raise exceptions.KeyDoesNotExist()
            with open(self.FilePath, "rb") as f:
                  data = pickle.load(f)
                  if (key not in data):
                        raise exceptions.KeyDoesNotExist()
                  return data[key]

      def GetKeys(self):
            if (os.path.getsize(self.FilePath)) < 1:
                  keys = []
                  return keys
            with open(self.FilePath, "rb") as f:
                  data = pickle.load(f)
                  keys = []
                  for key, data in data.items():
                        keys.append(key)
                  return keys

      def DeleteKey(self, key: str):
            if (os.path.getsize(self.FilePath)) < 1:
                  raise exceptions.KeyDoesNotExist()
            if (key not in self.GetKeys()):
                  raise exceptions.KeyDoesNotExist()
            with open(self.FilePath, "rb") as f:
                  CurrentData = pickle.load(f)
            CurrentData.pop(key)
            with open(self.FilePath, "wb") as f:
                  pickle.dump(CurrentData, f)
            

      def save(self):
            if (os.path.getsize(self.FilePath)) > 0:
                  with open(self.FilePath, "rb") as f:
                        CurrentData = pickle.load(f)
            else:
                  CurrentData = {}

            for key, data in self.DataToSave.items():
                  CurrentData[key] = data

            with open(self.FilePath, "wb") as f:
                  pickle.dump(CurrentData, f)

def GetFile(filename: str) -> File:
      return File(filename)
